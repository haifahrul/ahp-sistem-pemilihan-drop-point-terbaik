# AHP-Sistem-Pemilihan-Drop-Point-Terbaik

Sistem Pemilihan Drop Point Terbaik

Sistem ini dibuat untuk membantu Management J&amp;T Express
dalam menentukan Drop Point area terbaik di Jakarta STAR
Langkah yang harus dilakukan
Buat seleksi baru (atau bisa disebut periode seleksi baru)
Setting kriteria seleksi yang digunakan
Masukkan data Alternatif yang nantinya akan diseleksi
Mulai seleksi dengan metode AHP
Masuk ke Nilai Kriteria dan isikan nilai perbandingan kriteria untuk menentukan bobot kriteria
Masuk ke Nilai Peserta Seleksi dan isikan nilai perbandingannya
Masuk hasil seleksi untuk melihat hasil akhir seleksinya
Anda dapat membuat seleksi baru lagi mulai dari penambahan seleksi baru